<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0014)about:internet -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Solomon Max</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="favicon.png">
<style type="text/css">
td img {display: block;}body,td,th {
	font-family: "Century Gothic";
	font-size: 13px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	text-align: center;
}
a:link {
	text-decoration: none;
	color: #F60;
}
a:visited {
	text-decoration: none;
	color: #F60;
}
a:hover {
	text-decoration: none;
	color: #000;
}
a:active {
	text-decoration: none;
}
</style>
<!--Fireworks CS6 Dreamweaver CS6 target.  Created Sat Oct 03 20:33:40 GMT+0100 2015-->
<script type="text/javascript">
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
</script>
</head>
<body bgcolor="#ffffff" onload="MM_preloadImages('images/index_r1_c1.png')">
<table width="1300" border="0" align="center" cellpadding="0" cellspacing="0" style="display: inline-table;">
<!-- fwtable fwsrc="index.png" fwpage="Page 1" fwbase="index.png" fwstyle="Dreamweaver" fwdocid = "977918733" fwnested="0" -->
  <tr>
   <td><img src="images/spacer.gif" width="194" height="1" alt="" /></td>
   <td><img src="images/spacer.gif" width="228" height="1" alt="" /></td>
   <td><img src="images/spacer.gif" width="206" height="1" alt="" /></td>
   <td><img src="images/spacer.gif" width="274" height="1" alt="" /></td>
   <td><img src="images/spacer.gif" width="204" height="1" alt="" /></td>
   <td><img src="images/spacer.gif" width="194" height="1" alt="" /></td>
   <td><img src="images/spacer.gif" width="1" height="1" alt="" /></td>
  </tr>

  <tr>
   <td>&nbsp;</td>
   <td><a href="http://www.solomonmax.com/sm/renewableenergy/" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Renewable Energy','','images/index_r1_c2a.png',0)"><img src="images/index_r1_c2.png" width="228" height="500" id="Renewable Energy" /></a></td>
   <td><a href="http://www.solomonmax.com/sm/realty/" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Realty','','images/index_r1_c3a.png',1)"><img src="images/index_r1_c3.png" name="Realty" width="206" height="500" id="Realty" /></a></td>
   <td><a href="http://www.solomonmax.com/sm/franchiseimportation/" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Franchise Importation','','images/index_r1_c4a.png',1)"><img src="images/index_r1_c4.png" width="274" height="500" id="Franchise Importation" /></a></td>
   <td><a href="http://www.solomonmaxng.com" target="_blank" onmouseover="MM_swapImage('HRS &amp; P','','images/index_r1_c5a.png',1)" onmouseout="MM_swapImgRestore()"><img src="images/index_r1_c5.png" width="204" height="500" id="HRS &amp; P" /></a></td>
   <td>&nbsp;</td>
   <td><img src="images/spacer.gif" width="1" height="500" alt="" /></td>
  </tr>
  <tr>
   <td colspan="6" style="background-image: url(images/index_r2_c1.png); text-align: center;"><p style="font-size: 22px; color: #F60;"><a href="http://www.solomonmax.com/sm/contact/">CONTACT</a></p>
    <p><script language="javascript" type="text/javascript">
<!--
 
//Script created by Ronny Drappier, http://sipreal.com
//Visit http://javascriptkit.com for this script
 
    today=new Date();
    y0=today.getFullYear();
 
  // end hiding --->
              </script>
     <span style="color: #666">Copyright © 2014 -
    <script language="javascript" type="text/javascript">
  <!--- Hide from old browsers
    document.write(y0);
  // end hiding --->
                </script>. Solomon Max. All Rights Reserved!</span></p></td>
   <td><img src="images/spacer.gif" width="1" height="100" alt="" /></td>
  </tr>
</table>
</body>
</html>
